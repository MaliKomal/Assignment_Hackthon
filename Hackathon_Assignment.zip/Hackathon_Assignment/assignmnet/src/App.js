// src/App.js

import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
// import Header from './components/Header';
import Home from './components/Home'; // Import your pages
import City from './components/City';
import State from './components/State';
import Warehouse from './components/Warehouse';
// import Login from './components/Login';

function App() {
  return (
    <Router>
      <div className="App">
        {/* <Navbar /> */}
        <Routes>
        {/* <Route path="/" element={<Login />} /> */}
          <Route path="/" element={<Home />} />
          <Route path="/city" element={<City />} />
          <Route path="/state" element={<State />} />
          <Route path="/warehouse" element={<Warehouse />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
