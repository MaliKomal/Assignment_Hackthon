const [isModalOpen, setIsModalOpen] = useState(false);

const handleDelete = () => {
  setIsModalOpen(true);
};

return (
  <>
    <button className="bg-red-500" onClick={handleDelete}>Delete</button>

    <Dialog open={isModalOpen} onClose={() => setIsModalOpen(false)}>
      <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
        <div className="bg-white p-6 rounded-lg">
          <Dialog.Title>Delete State</Dialog.Title>
          <p>Are you sure you want to delete this state?</p>
          <button onClick={() => setIsModalOpen(false)}>Cancel</button>
          <button onClick={() => confirmDelete()}>Confirm</button>
        </div>
      </div>
    </Dialog>
  </>
);
