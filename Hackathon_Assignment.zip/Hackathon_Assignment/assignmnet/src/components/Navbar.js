import React from 'react';
import { FaUserCircle } from 'react-icons/fa'; // Import the user profile icon

const Navbar = () => {
  return (
    <nav className="bg-purple-900 shadow-md p-4 flex justify-between items-center">
      {/* Logo and Company Name */}
      <div className="flex items-center space-x-4">
        {/* Square D Symbol */}
        <div className="text-white font-bold w-10 h-10 flex items-center justify-center rounded-md">
          D
        </div>

        {/* Company Name */}
        <div className="text-xl font-bold text-white">DigitatFlake</div>
      </div>

      {/* Profile Section */}
      <div className="flex items-center space-x-4">
      
       
        
        {/* Profile Icon with White Border */}
        <FaUserCircle 
          className="w-10 h-10 text-white mr-6"
          
        />
      </div>
    </nav>
  );
}

export default Navbar;
