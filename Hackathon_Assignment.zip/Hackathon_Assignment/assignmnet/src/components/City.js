import React, { useState } from 'react';
import Navbar from './Navbar.js';
import Header from './Header.js';

import { FaEdit, FaTrash, FaCity,FaSearch, FaPlus, FaArrowLeft } from 'react-icons/fa';

const StateTable = () => {
  const [entries, setEntries] = useState([
    { id: 123, stateName: 'Maharashtra', stateCode: 'MH15', status: 'Active' },
    { id: 124, stateName: 'Telangana', stateCode: 'TN24', status: 'Active' },
    { id: 125, stateName: 'Gandhinagar', stateCode: 'GJ07', status: 'Inactive' },
  ]);

  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedEntry, setSelectedEntry] = useState(null);
  const [showAddStateForm, setShowAddStateForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(null);
  const [newStateName, setNewStateName] = useState('');
  const [newStateCode, setNewStateCode] = useState('');
  const [editStateName, setEditStateName] = useState('');
  const [editStateCode, setEditStateCode] = useState('');
  const [editStateStatus, setEditStateStatus] = useState('');

  const handleDeleteClick = (entry) => {
    setSelectedEntry(entry);
    setShowDeleteModal(true);
  };

  const confirmDelete = () => {
    setEntries(entries.filter((entry) => entry.id !== selectedEntry.id));
    setShowDeleteModal(false);
  };

  const handleAddNewClick = () => {
    setShowAddStateForm(true);
  };

  const handleAddState = () => {
    const newEntry = {
      id: Date.now(), // Unique ID for new entry
      stateName: newStateName,
      stateCode: newStateCode,
      status: 'Active', // Default status
    };
    setEntries([...entries, newEntry]);
    setNewStateName('');
    setNewStateCode('');
    setShowAddStateForm(false);
  };

  const handleEditClick = (entry) => {
    setEditStateName(entry.stateName);
    setEditStateCode(entry.stateCode);
    setEditStateStatus(entry.status);
    setShowEditForm(entry);
  };

  const handleSaveEdit = () => {
    const updatedEntries = entries.map((entry) =>
      entry.id === showEditForm.id
        ? { ...entry, stateName: editStateName, stateCode: editStateCode, status: editStateStatus }
        : entry
    );
    setEntries(updatedEntries);
    setShowEditForm(null);
  };

  return (
    <div className="flex flex-1 flex-col">
      <Navbar />
      <div className="flex flex-1">
        {/* Sidebar (Header) */}
        <div className="w-1/4 bg-gray-200">
          <Header />
        </div>

        {/* Main Content */}
        <div className="flex-1 p-6">
          {showAddStateForm ? (
            <div className="relative bg-white p-6 rounded">
              <div className=" items-center mb-4">
                <button
                  onClick={() => setShowAddStateForm(false)}
                  className=" text-black px-4 py-2 flex items-center font-bold"
                >
                  <FaArrowLeft className="mr-2" />
                  Add City
                </button>
              </div>
              <div className="mb-4">
                <label className="block mb-2 text-gray-700">City Name</label>
                <input
                  type="text"
                  value={newStateName}
                  onChange={(e) => setNewStateName(e.target.value)}
                  className="border border-gray-300 px-4 py-2 rounded w-full"
                />
               
                <label className="block mb-2 text-gray-700">City Code</label>
                <input
                  type="text"
                  value={newStateCode}
                  onChange={(e) => setNewStateCode(e.target.value)}
                  className="border border-gray-300 px-4 py-2 rounded w-full"
                />
            
              </div>
             
              <div className="flex justify-end space-x-4 mt-6">
                <button
                  onClick={() => setShowAddStateForm(false)}
                  className="bg-gray-200 px-4 py-2 rounded"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddState}
                  className="bg-purple-700 text-white px-4 py-2 rounded"
                >
                  Save
                </button>
              </div>
            </div>
          ) : showEditForm ? (
            <div className="relative bg-white p-6 rounded shadow-md">
              <div className="flex justify-between items-center mb-4">
                <button
                  onClick={() => setShowEditForm(null)}
                  className="bg-gray-200 text-black px-4 py-2 rounded flex items-center"
                >
                  <FaArrowLeft className="mr-2" />
                  Edit State
                </button>
              </div>
              <div className="mb-4">
                <label className="block mb-2 text-gray-700">City Name</label>
                <input
                  type="text"
                  value={editStateName}
                  onChange={(e) => setEditStateName(e.target.value)}
                  className="border border-gray-300 px-4 py-2 rounded w-full"
                />
              </div>
              <div className="mb-4">
                <label className="block mb-2 text-gray-700">City Code</label>
                <input
                  type="text"
                  value={editStateCode}
                  onChange={(e) => setEditStateCode(e.target.value)}
                  className="border border-gray-300 px-4 py-2 rounded w-full"
                />
              </div>
              <div className="mb-4">
                <label className="block mb-2 text-gray-700">State</label>
                <select
                  value={editStateStatus}
                  onChange={(e) => setEditStateStatus(e.target.value)}
                  className="border border-gray-300 px-4 py-2 rounded w-full"
                >
                  <option value="Active">Maharashtra</option>
                  <option value="Inactive">Telangana</option>
                </select>
              </div>
              <div className="mb-4">
                <label className="block mb-2 text-gray-700">Status</label>
                <select
                  value={editStateStatus}
                  onChange={(e) => setEditStateStatus(e.target.value)}
                  className="border border-gray-300 px-4 py-2 rounded w-full"
                >
                  <option value="Active">Active</option>
                  <option value="Inactive">Realme</option>
                </select>
              </div>
              <div className="flex justify-end space-x-4 mt-6">
                <button
                  onClick={() => setShowEditForm(null)}
                  className="bg-gray-200 px-4 py-2 rounded"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveEdit}
                  className="bg-purple-700 text-white px-4 py-2 rounded"
                >
                  Save
                </button>
              </div>
            </div>
          ) : (
            <>
              {/* Component Header */}
              <div className="flex justify-between items-center mb-4">
              <FaCity/> 
                <h1 className="text-xl font-bold text-gray-800">City</h1>
                <div className="flex items-center space-x-2">
                  <div className="relative">
                    <FaSearch className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-600" />
                    <input
                      type="text"
                      placeholder="Search"
                      className="border border-gray-300 px-8 py-1 rounded focus:outline-none focus:ring-2 focus:ring-purple-700 pl-8"
                    />
                  </div>
                </div>

                <button
                  onClick={handleAddNewClick}
                  className="bg-purple-700 text-white px-4 py-2 rounded flex items-center"
                >
                  <FaPlus className="mr-2" />
                  Add New
                </button>
              </div>

              {/* State Table */}
              <table className="min-w-full bg-white shadow-md rounded-lg overflow-hidden">
                <thead className="bg-yellow-100 text-black">
                  <tr>
                    <th className="py-3 px-6 text-left">ID</th>
                    <th className="py-3 px-6 text-left">City Name</th>
                    <th className="py-3 px-6 text-left">City Code</th>
                    <th className="py-3 px-6 text-left">Status</th>
                    <th className="py-3 px-6 text-left">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {entries.map((entry) => (
                    <tr key={entry.id} className="border-b">
                      <td className="py-3 px-6">{entry.id}</td>
                      <td className="py-3 px-6">{entry.stateName}</td>
                      <td className="py-3 px-6">{entry.stateCode}</td>
                      <td className="py-3 px-6">
                        <span
                          className={`${
                            entry.status === 'Active' ? 'text-green-500' : 'text-red-500'
                          }`}
                        >
                          {entry.status}
                        </span>
                      </td>
                      <td className="py-3 px-6">
                        <FaEdit
                          className="cursor-pointer mr-4 inline"
                          onClick={() => handleEditClick(entry)}
                        />
                        <FaTrash
                          className="cursor-pointer inline"
                          onClick={() => handleDeleteClick(entry)}
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </>
          )}

          {/* Delete Modal */}
          {showDeleteModal && (
            <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
              <div className="bg-white px-12 py-8 rounded-lg shadow-lg relative">
                <div className="flex justify-center items-center">
                  {/* Warning symbol */}
                  <span className="text-red-500 text-3xl mr-2">!</span>
                  <h2 className="text-black-600 text-xl font-bold text-center">Delete</h2>
                </div>
                <p className="mt-2 text-center">Are you sure you want to delete?</p>

                <div className="flex justify-end space-x-4 mt-6">
                  {/* Cancel Button */}
                  <button
                    onClick={() => setShowDeleteModal(false)}
                    className="bg-gray-200 px-6 py-2 rounded-lg text-lg"
                  >
                    Cancel
                  </button>
                  {/* Confirm Delete Button */}
                  <button
                    onClick={confirmDelete}
                    className="bg-purple-900 text-white px-6 py-2 rounded-lg text-lg"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const City = () => {
  return (
    <div className="flex flex-col h-screen">
      <StateTable />
    </div>
  );
};

export default City;
