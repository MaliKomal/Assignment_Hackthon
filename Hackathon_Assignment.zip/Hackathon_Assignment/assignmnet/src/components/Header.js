import React from "react";
import { NavLink, useLocation } from "react-router-dom";
import { FaHome, FaCity, FaWarehouse, FaFlag,FaSortLeft } from "react-icons/fa";

const Header = () => {
  const location = useLocation();

  return (
    <nav className="flex flex-col space-y-4 p-4 bg-gray-200">
      <NavLink
        to="/"
        className={`flex items-center p-2 ${location.pathname === "/" ? "bg-yellow-100" : ""}`}
      >
        <FaHome className="mr-2" /> Home
        <span className="ml-auto">{location.pathname === "/" && <span>→</span>}</span>
      </NavLink>

      <NavLink
        to="/city"
        className={`flex items-center p-2 ${location.pathname === "/city" ? "bg-yellow-100" : ""}`}
      >
        <FaCity className="mr-2" /> City
        <span className="ml-auto">{location.pathname === "/city" && <span>→</span>}</span>
      </NavLink>

      <NavLink
        to="/state"
        className={`flex items-center p-2 ${location.pathname === "/state" ? "bg-yellow-100" : ""}`}
      >
        <FaFlag className="mr-2" /> State
        <span className="ml-auto">{location.pathname === "/state" && <span>→</span>}</span>
      </NavLink>

      <NavLink
        to="/warehouse"
        className={`flex items-center p-2 ${location.pathname === "/warehouse" ? "bg-yellow-100" : ""}`}
      >
        <FaWarehouse className="mr-2" /> Warehouse
        <span className="ml-auto">{location.pathname === "/warehouse" && <span>→</span>}</span>
      </NavLink>
    </nav>
  );
};

export default Header;
