// src/City.js

import React from 'react';
import { FaHome, FaWarehouse, FaCity, FaFlag } from 'react-icons/fa'; // Import icons
import Navbar from './Navbar';
import Header from './Header';

const City = () => {
  return (
    <div>
      <Navbar />
      <div className="flex h-screen">
        {/* Sidebar */}
        <aside className="w-1/4 bg-gray-200 p-5 flex flex-col ">
          <Header />
      
        </aside>

        {/* Main content area */}
        <main className="flex-grow p-8 bg-white flex flex-col justify-center items-center">
        <span className="text-white bg-purple-700 border-4 border-white px-3 py-2 rounded-lg text-2xl">D</span>
          <div className="text-4xl font-bold flex items-center">
            
            digital<span className="font">Flake</span>
          </div>
          <p className="text-center mt-4">Welcome to DigitalFlake admin</p>
        </main>
      </div>
    </div>
  );
};

export default City;
