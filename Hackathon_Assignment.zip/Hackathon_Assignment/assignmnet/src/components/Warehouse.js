import React, { useState } from 'react';
import Navbar from './Navbar.js';
import Header from './Header.js';
import { FaEdit, FaTrash, FaSearch, FaPlus, FaWarehouse, FaArrowLeft, FaSortUp, FaSortDown } from 'react-icons/fa';

const StateTable = () => {
  const [entries, setEntries] = useState([
    { id: 123, stateName: 'Maharashtra', stateCode: 'MH15', city: 'Mumbai', status: 'Active' },
    { id: 124, stateName: 'Telangana', stateCode: 'TN24', city: 'Pune', status: 'Active' },
    { id: 125, stateName: 'Gandhinagar', stateCode: 'GJ07', city: 'Ahmedabad', status: 'Inactive' },
  ]);

  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedEntry, setSelectedEntry] = useState(null);
  const [showAddStateForm, setShowAddStateForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(null);

  const handleDeleteClick = (entry) => {
    setSelectedEntry(entry);
    setShowDeleteModal(true);
  };

  const confirmDelete = () => {
    setEntries(entries.filter((entry) => entry.id !== selectedEntry.id));
    setShowDeleteModal(false);
  };

  const handleAddNewClick = () => {
    setShowAddStateForm(true);
  };

  const handleEditClick = (entry) => {
    setShowEditForm(entry);
  };

  return (
    <div className="flex flex-1 flex-col">
      <Navbar />
      <div className="flex flex-1">
        <div className="w-1/4 bg-gray-200">
          <Header />
        </div>

        <div className="flex-1 p-6">
          {showAddStateForm ? (
            <div>
              {/* Add form content */}
            </div>
          ) : showEditForm ? (
            <div>
              {/* Edit form content */}
            </div>
          ) : (
            <>
              <div className="flex justify-between items-center mb-4">
                <FaWarehouse />
                <h1 className="text-xl font-bold text-gray-800">Warehouse</h1>
                <div className="flex items-center space-x-2">
                  <div className="relative">
                    <FaSearch className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-600" />
                    <input
                      type="text"
                      placeholder="Search"
                      className="border border-gray-300 px-8 py-1 rounded pl-8"
                    />
                  </div>
                </div>
                <button
                  onClick={handleAddNewClick}
                  className="bg-purple-700 text-white px-4 py-2 rounded flex items-center"
                >
                  <FaPlus className="mr-2" />
                  Add New
                </button>
              </div>

              {/* Table */}
              <table className="min-w-full bg-white border border-gray-200">
              <thead className="bg-yellow-100 text-black border-b">
  <tr>
    <th className="py-3 px-6 text-left border-r">
      <div className="flex items-center">
        <span>ID</span>
        <div className="flex flex-col ml-2 space-y-0">
          <FaSortUp />
          <FaSortDown />
        </div>
      </div>
    </th>
    <th className="py-3 px-6 text-left border-r">
      <div className="flex items-center">
        <span>Name</span>
        <div className="flex flex-col ml-2 space-y-0">
          <FaSortUp />
          <FaSortDown />
        </div>
      </div>
    </th>
    <th className="py-3 px-6 text-left border-r">
      <div className="flex items-center">
        <span>State</span>
        <div className="flex flex-col ml-2 space-y-0">
          <FaSortUp />
          <FaSortDown />
        </div>
      </div>
    </th>
    <th className="py-3 px-6 text-left border-r">
      <div className="flex items-center">
        <span>City</span>
        <div className="flex flex-col ml-2 space-y-0">
          <FaSortUp />
          <FaSortDown />
        </div>
      </div>
    </th>
    <th className="py-3 px-6 text-left border-r">
      <div className="flex items-center">
        <span>Status</span>
        <div className="flex flex-col ml-2 space-y-0">
          <FaSortUp />
          <FaSortDown />
        </div>
      </div>
    </th>
    <th className="py-3 px-6 text-left">Action</th>
  </tr>
</thead>


                <tbody>
                  {entries.map((entry) => (
                    <tr key={entry.id} className="border-b">
                      <td className="py-3 px-6 border-r">{entry.id}</td>
                      <td className="py-3 px-6 border-r">{entry.stateName}</td>
                      <td className="py-3 px-6 border-r">{entry.stateCode}</td>
                      <td className="py-3 px-6 border-r">{entry.city}</td>
                      <td className="py-3 px-6 border-r">
                        <span
                          className={
                            entry.status === 'Active' ? 'text-green-500' : 'text-red-500'
                          }
                        >
                          {entry.status}
                        </span>
                      </td>
                      <td className="py-3 px-6">
                        <FaEdit className="cursor-pointer mr-4 inline" onClick={() => handleEditClick(entry)} />
                        <FaTrash className="cursor-pointer inline" onClick={() => handleDeleteClick(entry)} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </>
          )}
          {showDeleteModal && (
            <div className="fixed inset-0 bg-gray-500 bg-opacity-50 flex items-center justify-center z-50">
              <div className="bg-white p-6 rounded shadow-md">
                <h2 className="text-lg font-bold mb-4">Confirm Deletion</h2>
                <p className="mb-4">Are you sure you want to delete the state entry?</p>
                <div className="flex justify-end space-x-4">
                  <button
                    onClick={() => setShowDeleteModal(false)}
                    className="bg-gray-200 px-4 py-2 rounded"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={confirmDelete}
                    className="bg-red-500 text-white px-4 py-2 rounded"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StateTable;
